import os
import streamlit as st
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.llms import HuggingFacePipeline
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter, Language
from langchain.schema import Document

# Set up paths and constants
CODE_FILES_PATH = './code'
EMBEDDING_MODEL_NAME = 'sentence-transformers/all-MiniLM-L6-v2'
GENERATION_MODEL_NAME = 'gpt2'

# Function to read and chunk code files
def read_and_chunk_code_files(path):
    code_documents = []
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith('.py'):  # Adjust for other languages as needed
                with open(os.path.join(root, file), 'r') as f:
                    code = f.read()
                    doc = Document(page_content=code, metadata={"filename": file})
                    code_documents.append(doc)
    
    text_splitter = RecursiveCharacterTextSplitter.from_language(
        language=Language.PYTHON, chunk_size=2000, chunk_overlap=200
    )
    code_chunks = text_splitter.split_documents(code_documents)
    return code_chunks

# Load code files and create embeddings
code_chunks = read_and_chunk_code_files(CODE_FILES_PATH)
embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL_NAME)

# Generate embeddings for the chunks
chunk_texts = [chunk.page_content for chunk in code_chunks]
chunk_embeddings = embeddings.embed_documents(chunk_texts)

# Check embeddings size and content
if len(chunk_embeddings) == 0 or len(chunk_embeddings[0]) == 0:
    raise ValueError("Embeddings are empty or not generated correctly")

# Create FAISS vectorstore
vectorstore = FAISS.from_texts(chunk_texts, embeddings)

# Load Hugging Face model for generation
tokenizer = AutoTokenizer.from_pretrained(GENERATION_MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(GENERATION_MODEL_NAME)
generation_pipeline = pipeline('text-generation', model=model, tokenizer=tokenizer)

# Set up Langchain RetrievalQA
prompt_template = PromptTemplate(template="Given the following code snippet:\n\n{context}\n\nAnswer the following question:\n\n{query}")
qa_chain = RetrievalQA(
    llm=HuggingFacePipeline(pipeline=generation_pipeline),
    retriever=vectorstore.as_retriever(),
    prompt_template=prompt_template
)

# Streamlit frontend
st.title("Code Assistance Chatbot")
user_input = st.text_input("Ask your coding question:")
if user_input:
    response = qa_chain.run({"query": user_input})
    st.write("Response:")
    st.write(response)
